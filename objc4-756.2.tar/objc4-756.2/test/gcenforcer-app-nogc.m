/*
fixme disabled in BATS because of gcfiles
TEST_CONFIG OS=macosx BATS=0

TEST_BUILD
    cp $DIR/gcfiles/$C{ARCH}-nogc gcenforcer-app-nogc.exe
END

TEST_RUN_OUTPUT
running
END
*/
